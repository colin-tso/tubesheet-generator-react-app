export const utils = {
    capitalize(x: string) {
        return String(x).charAt(0).toUpperCase() + String(x).slice(1);
    },
    numFormat3SigFigs(x: number) {
        if (x > 100) {
            return this.numberWithCommas(Math.ceil(x));
        } else {
            return this.numberWithCommas(parseFloat((x as number).toPrecision(3)));
        }
    },
    numberWithCommas(x: number) {
        return x.toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ",");
    },
    round(num: number, decimalPlaces = 0) {
        const p = Math.pow(10, decimalPlaces);
        const n = num * p * (1 + Number.EPSILON);
        return Math.round(n) / p;
    },
    trunc(num: number, decimalPlaces = 0) {
        const p = Math.pow(10, decimalPlaces);
        const n = num * p * (1 + Number.EPSILON);
        return Math.trunc(n) / p;
    },
    isNumber(x: unknown): x is number {
        return (
            (typeof x === "number" && x - x === 0) ||
            (typeof x === "string" && Number.isFinite(+x.replace(",", "")) && x.trim() !== "")
        );
    },
    stringToNumber(x: string) {
        return parseFloat(x.replace(",", ""));
    },
    symlog(x: number, c: number = 1) {
        return Math.sign(x) * Math.log10(Math.abs(x) / c + 1);
    },
};
